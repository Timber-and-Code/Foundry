# Ledger Row

Replaces "cards" for list content. Thin horizontal rules, dense horizontal rhythm, phase-color accent bar on the left. Used for set logging, upcoming weeks, exercise queues, history entries.

## Anatomy

```
│ 03  [weight] [reps] [rpe]   (✓)    │  ← active row, left bar glows
│────────────────────────────────────│
│ 04  [weight] [reps] [rpe]   ( )    │  ← pending row, no bar
```

## Spec

### Container
- `display: grid` with explicit columns per use case
- `gap: --sp-2` (8px) or `--sp-3` (12px) between columns
- `padding: --sp-3` (12px) vertical, zero horizontal (container provides gutter)
- `border-bottom: 1px solid --border-dim` (#1a1614)
- `align-items: center`
- Background: transparent by default

### States

**Default:** background transparent, left bar absent.

**Active (current):**
- `background: linear-gradient(90deg, rgba(232,101,26,0.09) 0%, transparent 100%)`
- If wrapped in a container with a 2px left border (`--border-left`), that border becomes phase color and glows: `box-shadow: -12px 0 12px -8px <phase>`

**Complete (logged):**
- `background: linear-gradient(90deg, rgba(232,101,26,0.05) 0%, transparent 100%)` — subtler than active
- Number in phase color (`--accent`)
- Field text in `--text-3` (a3a3a3), underlines removed

**Empty/pending:** no background, no bar, text in `--text-5`.

### Row number (leftmost column)
- `--font-display` (Bebas Neue), `--size-set-num` (20px)
- Zero-padded two-digit format: `01`, `02`, `12`
- Color by state: default `--text-5`, active `--text-hi`, complete `--accent`
- Column width fixed (usually 32px)

### Fields (weight / reps / rpe or similar)
- Background: transparent
- Border: bottom-only, 1px solid `--border-2`
- Focus border-bottom: `--accent`
- Text: `--size-input` (15px), `--font-ui`, tabular-nums
- Center-aligned
- Placeholder: em-dash `—`
- When row is complete, border-bottom becomes transparent (no visual line)

### Action button (rightmost, e.g. checkmark)
- 32–36px square
- Default: 1px border `--border-3`, transparent background, checkmark in `--text-6`
- Done: `--accent` background, dark (`--bg-deep`) checkmark, ring-burst animation on transition to done

## Implementation (React + dnd-kit for reorderable cases)

```jsx
<div
  className={cn(
    "grid items-center py-3 border-b border-[#1a1614]",
    state === "active" && "bg-gradient-to-r from-[rgba(232,101,26,0.09)] to-transparent",
    state === "done" && "bg-gradient-to-r from-[rgba(232,101,26,0.05)] to-transparent"
  )}
  style={{ gridTemplateColumns: "32px 1fr 1fr 1fr 44px", gap: "10px" }}
>
  <span className="font-[Bebas_Neue] text-[20px]" style={{ color: numColor }}>
    {String(num).padStart(2, "0")}
  </span>
  {/* fields */}
  {/* action button */}
</div>
```

Prefer extracting a `<LedgerRow>` component with slots for leading number, fields, and trailing action, rather than duplicating the grid across screens.

## When to use vs. cards

**Use ledger rows:** anywhere data is tabular or list-like, anywhere horizontal rhythm matters (set logging, week history, workout history, exercise queue).

**Don't use ledger rows:** primary CTA containers (use a distinct callout block with a phase-color left bar 2px wide), onboarding cards (those are genuine cards with their own treatment).
