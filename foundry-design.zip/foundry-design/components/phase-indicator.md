# Phase Indicator

The 2–4px vertical accent bar that marks the currently-active element. Phase-colored, optionally glowing.

## Variants

### Inline (next to text)
- 4px width, 16px height
- Inline-block, margin-right 12–16px
- Background: phase color
- No glow, no animation

Used for: upcoming week rows, exercise queue items, phase legend.

### Container-left (border)
- 2px border-left on a containing block
- Phase color
- When *current* state, add `box-shadow: 0 0 12px <phase>` on the border (via absolute pseudo-element since `border` can't have shadow on its own)

Used for: the active exercise in Focus Mode, the "Now Forging" callout, rest timer panel.

### Strike tick (progress segmentation)
- 3–4px height, full-width horizontal bar split into equal segments with 3px gaps
- Each segment represents one unit of progress (one set, one exercise, one session)
- Completed: phase color with soft glow
- Current: `--text-hi` (white), with a pulse animation
- Upcoming: `--border-2` (#262626), no glow

Used for: session progress dots on Focus Mode header, meso heat curve labels.

## Implementation

```jsx
// Inline
<span
  className="inline-block w-1 h-4 mr-4"
  style={{ background: phaseColor }}
/>

// Container-left (active + glowing)
<article className="relative border-l-2 pl-4" style={{ borderColor: phaseColor }}>
  <span
    aria-hidden
    className="absolute -left-[2px] top-0 bottom-0 w-[2px]"
    style={{ background: phaseColor, boxShadow: `0 0 12px ${phaseColor}` }}
  />
  {/* content */}
</article>

// Strike tick
<div className="flex gap-[3px]">
  {segments.map((s, i) => (
    <div
      key={i}
      className={cn("flex-1 h-1", {
        "bg-[#262626]": s === "upcoming",
        "bg-white animate-pulse-glow": s === "current",
      })}
      style={s === "done" ? { background: phaseColor, boxShadow: `0 0 4px ${phaseColor}80` } : {}}
    />
  ))}
</div>
```

## Color source

Always import from the phase registry, never hardcode:

```js
import { PHASE_COLORS } from '@/design/colors';
const color = PHASE_COLORS[currentPhase]; // 'Accumulation' → '#E8E4DC', etc.
```
