# Editorial Header

Screen-opening pattern: meta row → divider → oversized Bebas Neue headline → status line. Used at the top of every primary screen.

## Anatomy

```
┌──────────────────────────────────┐
│ MESO 07          FORGE LOG       │  ← meta row (size-label, text-4)
├──────────────────────────────────┤  ← divider (gradient rule)
│                                  │
│ STRIKE                           │
│ WHILE                            │  ← headline (size-hero / size-screen)
│ HOT.                             │
│                                  │
│ PPLPP / WK 04 OF 07 / ● INTENS.  │  ← status line (size-small, text-3)
└──────────────────────────────────┘
```

## Spec

### Meta row
- `flex justify-between items-baseline`
- Both labels `--size-label` (10px), `--track-wide` (0.3em), uppercase, `--text-4` (#737373)
- Margin bottom: `--sp-1` (4px)

### Divider
- 1px height
- `background: linear-gradient(90deg, #404040, #525252, transparent)`
- Margin bottom: `--sp-5` (20px)

### Headline
- `font-family: var(--font-display)` (Bebas Neue)
- `font-size: var(--size-hero)` (56px) for primary screens, `--size-screen` (48px) for secondary
- `line-height: 0.88–0.92`
- `letter-spacing: 0.01em`
- Color: `--text-hi` (#f5f5f5)
- Accent word (if any) uses current phase color
- Margin bottom: `--sp-3` (12px)

### Status line
- `flex items-center gap-3`
- `--size-small` (11px), `--text-3` (#a3a3a3)
- Separator character `/` in `--border-3` (#404040)
- Current phase marker uses phase color with `● PHASE_NAME` format
- Margin bottom: varies by screen (usually `--sp-8` to `--sp-10`)

## Implementation (React)

```jsx
<header className="mb-10">
  <div className="flex justify-between items-baseline mb-1">
    <span className="text-[10px] tracking-[0.3em] text-neutral-500 uppercase">{metaLeft}</span>
    <span className="text-[10px] tracking-[0.3em] text-neutral-500 uppercase">{metaRight}</span>
  </div>

  <div className="h-px bg-gradient-to-r from-neutral-700 via-neutral-600 to-transparent mb-5" />

  <h1
    className="text-[56px] leading-[0.88] text-neutral-100 mb-3"
    style={{ fontFamily: 'Bebas Neue, sans-serif', letterSpacing: '0.01em' }}
  >
    {children}
  </h1>

  <div className="flex items-center gap-3 text-[11px] text-neutral-400 tracking-wider">
    {/* status items */}
  </div>
</header>
```

Build as `<EditorialHeader>` accepting `metaLeft`, `metaRight`, `title` (can be JSX with accent span), and `status` (array of strings/nodes). Keep it a presentation component — no data fetching.

## Examples by screen

**Home:** META "TODAY" / "DAY 01 W04" · TITLE "PUSH" · STATUS "06 EXERCISES / ~65 MIN / ● INTENSIFICATION"

**Progress:** META "PROGRESS" / "MESO 07" · TITLE "OUTPUT" · STATUS "12 SESSIONS / 4 WKS"

**Schedule (Meso Overview):** META "MESO 07" / "FORGE LOG" · TITLE "STRIKE WHILE HOT." · STATUS "PPLPP / WK 04 OF 07 / ● INTENSIFICATION"

**Explore:** META "LIBRARY" / "159 MOVEMENTS" · TITLE "EXPLORE" · STATUS categories / filters

Each screen picks language appropriate to itself. Headlines can be single-word ("OUTPUT"), multi-line ("STRIKE / WHILE / HOT."), or functional ("EXPLORE") — the *treatment* is consistent.
