# Heat Haze

Radial gradient in the current phase color, anchored to the top of the viewport. Makes the app feel *warm* in Intensification, *cool* in Deload — the whole screen subtly shifts mood based on where the user is in their mesocycle.

## Spec

- Fixed-position or absolute (screen-container-relative) element
- Top of screen, 320–384px tall
- Radial gradient from `{phaseColor}22` (13% opacity) at the top, fading to transparent by 60–65%
- `pointer-events: none`
- Sits above the background, below noise overlay and content

## Implementation (React)

```jsx
import { usePhase } from '@/hooks/usePhase'; // returns current phase name
import { PHASE_COLORS } from '@/design/colors';

export function HeatHaze() {
  const phase = usePhase();
  const color = PHASE_COLORS[phase] ?? PHASE_COLORS.Accumulation;

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed top-0 left-0 right-0 h-96 z-[1]"
      style={{
        background: `radial-gradient(ellipse at 50% 0%, ${color}22 0%, transparent 65%)`,
      }}
    />
  );
}
```

## Usage

Mount once at the app root, same layer as `<NoiseOverlay>`. The component subscribes to the current phase and updates automatically when the user progresses through the mesocycle.

## Intensity variations

Some screens benefit from a stronger haze:
- **Focus Mode (active workout):** anchor point `30% 0%` to bias slightly left, `#E8651A22` regardless of phase, since the user is actively training
- **Default / other screens:** `50% 0%`, phase color

Handle this with a `variant` prop if needed, not by duplicating the component.

## Transitions

When phase changes (e.g. user completes final Intensification week), the haze should crossfade between colors over 800ms. Do not hard-swap.
