# Noise Overlay

Subtle film-grain texture applied above the background on every screen. Single biggest "not AI-generated" signal in the system.

## Spec

- Fixed-position element, `inset: 0`, `z-index: 1`, `pointer-events: none`
- SVG turbulence filter as inline data URI background
- Opacity `0.08`, `mix-blend-mode: overlay`
- Renders above gradients, below all content

## Implementation (React)

Component lives at `src/components/atmosphere/NoiseOverlay.jsx`. Renders once at the app root, not per-screen. Already fixed to viewport so it persists across route changes.

```jsx
export function NoiseOverlay() {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-[1] opacity-[0.08] mix-blend-overlay"
      style={{
        backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>")`,
      }}
    />
  );
}
```

## Usage

Mount once in the root layout, outside `<Outlet>` or the tab router. Do not mount per-screen.

## Tuning

- Increase opacity to 0.12 on pure `#000` backgrounds if the noise doesn't read
- Drop opacity to 0.05 if it becomes distracting at larger viewport sizes
- Do not swap the SVG filter values — `baseFrequency 0.9` + `numOctaves 2` is deliberately calibrated
