# Focus Mode — Workout Logging

The in-workout screen. Single exercise focus at a time, with the next exercise previewed and full reorder capability via bottom sheet. Entered by tapping today's workout from Home (or similar).

## Reference mockup

`mockups/foundry-focus-mode.html`

## Design principle

During a workout the user is tired and distracted. The screen must answer three questions at a glance:

1. **What am I doing right now?** (large, centered exercise name)
2. **What did I do last time?** (always visible, no taps required)
3. **What's next?** (up-next card at the bottom)

Everything else is secondary and either collapsed into progress dots or tucked behind the Reorder button.

## Layout (top to bottom)

1. **Top bar** (compact, 14px padding bottom, border-bottom `--border-1`)
   - Left: `← EXIT` link, `--size-label`, `--text-4`
   - Center: session title (e.g. `PUSH A`) in Bebas, `--size-body`, `--track-brand`, `--text-3`
   - Right: session timer with pulsing ember dot, `--accent`, `--size-meta`, tabular-nums

2. **Session progress** (below top bar)
   - Label row: `SESSION PROGRESS` left, `02 / 06` right (completed / total), both `--size-label`
   - Progress dots: 6 thin 3px bars, gap 4px, full-width
     - Complete: phase-color with 4px glow
     - Current: `--text-hi` (white) with pulsing glow
     - Upcoming: `--border-2` (no glow)
   - Dots are tappable — tap jumps to that exercise
   - Below dots: 28px bottom margin

3. **Exercise focus block** (the main content)
   - Position chip: `EXERCISE 01 OF 06` in `--size-label` `--text-5`
   - Name: Bebas Neue `--size-section` (44px), `--text-hi`, line-height 0.92, `letter-spacing: 0.01em`
   - Meta row: `4 SETS / 6–8 REPS / RPE 08`, slash separators in `--border-3` (#333), labels in `--text-4`
   - Reference row (two columns, bordered container):
     - Left block (`TARGET`): phase color value in Bebas 18px (e.g. `200 LB`)
     - Right block (`LAST WEEK`): `--text-2` value in Bebas 18px (e.g. `185 × 8 @ 7.5`)
     - Column divider: 1px `--border-1`

4. **Sets ledger**
   - Column header row: `#` / `LBS` / `REPS` / `RPE` / (blank for action button)
   - Uses `components/ledger-row.md` pattern
   - Grid: `32px 1fr 1fr 1fr 44px` with 10px gap
   - Each row shows set number, weight, reps, RPE, complete button
   - **Active set** (first incomplete) gets active-state background
   - **Completed sets** get complete-state background, inputs become readonly, border-bottoms on inputs vanish
   - **Log button** is 36px square: default outline, orange fill when complete with ring-burst animation on click
   - Below last set: `+ ADD SET` row (dashed placeholder button on right, label centered left)

5. **Notes strip** (below sets)
   - Single row: pencil icon + `ADD NOTE` label
   - Border `--border-1`, subtle surface fill
   - Opens a note editor sheet on tap (stub for now)

6. **Up Next card** (below notes, 28px top margin)
   - Container: 1px border `--border-1`, 2px left border `--border-3` (hover: `--text-4`), `--surface-2` background
   - Label: `UP NEXT` in `--size-micro` `--text-5`
   - Name: Bebas `--size-card-title` (20px), `--text-2`
   - Meta: sets/reps/RPE in `--size-micro` `--text-5`
   - Right-aligned `›` arrow in `--text-5`
   - Tap → jumps to that exercise

7. **Fixed bottom nav bar** (safe area respected)
   - Gradient fade from transparent to `--bg-deep` (35% stop)
   - Three buttons in `grid-cols-[48px_1fr_48px]`, 10px gap:
     - Left: `‹` previous exercise (secondary button style)
     - Center: `REORDER` primary button in Bebas 16px, phase-color background with orange glow shadow
     - Right: `›` next exercise (secondary button style)

## Rest panel

When a set is logged, a floating panel slides up from above the nav bar with the rest timer.

- Position: `fixed bottom-[92px]`, left/right 16px, max-width 388px centered
- Container: vertical gradient `#1a1412` to `#0f0c0b`, 1px border, 2px left border in `--accent`
- Content: `REST` label + MM:SS timer in Bebas 28px `--accent`, tabular-nums
- Right: `SKIP` button, `--size-label`, `--text-3`, 1px border `--border-3`
- Slide-up animation on mount (0.3s, 20px translateY, opacity 0→1)
- Auto-dismiss when timer hits zero

## Reorder sheet

Entered via the `REORDER` button (or programmatically when user taps Up Next in certain cases).

### Interaction pattern — critical

**Use `@dnd-kit/core` with `@dnd-kit/sortable` and `PointerSensor`/`TouchSensor` configured for long-press activation.**

- Tap a row = jump to that exercise (close sheet)
- Long-press a row (~400ms) = enter drag mode
- Drag to reorder
- Release to drop

Do not implement drag/drop by hand. The mockup version had edge cases around synthetic click events, scroll conflicts, and auto-scroll that dnd-kit already solves. Install:

```
pnpm add @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities
```

Configure the pointer sensor with `activationConstraint: { delay: 400, tolerance: 8 }` so that a quick tap fires the click handler (jump) and a slow press activates the drag.

### Sheet structure

- Backdrop: fixed inset-0, `rgba(0,0,0,0.7)`, backdrop-blur 4px, fade in 0.2s
- Sheet: `fixed bottom-0`, slides up from below (transform 100% → 0, 0.3s)
- Max-width 420px, max-height 85vh, vertical scroll inside
- Handle pill at top (36px × 3px, `--border-3`, centered)
- Title: `REORDER SESSION` in Bebas 24px
- Subtitle: `Tap to jump · Hold to reorder` in `--size-label` `--text-4`
- List: sortable context wrapping all reorder items
- Actions at bottom (2-column grid): `CANCEL` outline / `APPLY` primary in phase color

### Reorder item

Each row:
- 1px border `--border-1`, subtle surface fill
- States: default / pressing (scale 0.99, faint orange tint) / dragging (scale 1.02, shadow + orange glow) / current (orange border) / done (opacity 0.45)
- Content: exercise number (Bebas 18px) / name (Bebas 16px) / meta (sets × reps) / status chip right-aligned
- No visible grip icon needed (the whole row is the target) — but a subtle `⋮⋮` in `--border-2` on the left reinforces draggability

### State preservation

- On sheet open, snapshot current order
- On `CANCEL`, restore snapshot
- On `APPLY`, keep current order; re-locate `currentIdx` by exercise ID (since positions changed)

## Interactions

- Tap log button on set → mark complete, show rest timer, auto-focus first input of next active set
- Tap log button on already-complete set → unmark (confirmation not needed)
- Tap `+ ADD SET` → append new empty set to current exercise
- Tap progress dot → jump to that exercise
- Tap Up Next card → jump to next incomplete exercise
- Tap `‹` / `›` in nav bar → step to adjacent exercise
- Tap `REORDER` → open reorder sheet

## Data required

```ts
type SetEntry = {
  weight: string;   // string to allow empty input
  reps: string;
  rpe: string;
  done: boolean;
};

type Exercise = {
  id: string;
  name: string;
  setsTarget: number;
  repLow: number;
  repHigh: number;
  rpeTarget: number;
  target: string;   // formatted target, e.g. "200 LB"
  lastWeek: string; // formatted previous performance
  sets: SetEntry[];
};

type Session = {
  id: string;
  name: string;          // 'PUSH A'
  dayOfMeso: number;
  weekOfMeso: number;
  phase: Phase;
  exercises: Exercise[];
  currentExerciseIdx: number;
  startedAt: number;
};
```

## Haptics

Wire up via `@capacitor/haptics` when running packaged. Fall back to `navigator.vibrate()` in PWA mode.

- Set logged: Light impact
- Drag activated (long-press fires): Medium impact
- Drag dropped on valid target: Light impact

## Acceptance criteria

- [ ] Single exercise fully rendered at a time; others only as progress dots + up-next
- [ ] Progress dots accurately reflect done/current/upcoming state and are tappable
- [ ] Active set auto-advances focus to the next set's first input on log
- [ ] Rest panel appears on set log, dismisses on zero or Skip
- [ ] Reorder implemented with dnd-kit (no hand-rolled touch handlers)
- [ ] Long-press ~400ms activates drag; shorter press jumps to exercise
- [ ] Tolerance on press (8px) allows scrolling without accidental drag
- [ ] Cancel on sheet restores original order; Apply preserves currentIdx by ID
- [ ] Noise overlay + heat haze present via app root
- [ ] Phase color drives accent throughout — changes if user is in Deload vs. Intensification
- [ ] No Inter; all text is Bebas Neue or JetBrains Mono
- [ ] Haptics wired for Capacitor build with `navigator.vibrate` fallback
- [ ] All functional copy ("Rest", "Complete", "Add Set", "Reorder") — no forge metaphor language in UI
