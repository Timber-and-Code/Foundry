# Schedule — Meso Overview

The Schedule tab's primary view. Shows the current mesocycle: where the user is, where they've been, what's ahead. Replaces the existing card-per-week layout with a heat curve + ledger combo.

## Reference mockup

`mockups/foundry-meso-comparison.html` — toggle to **Foundry** view.

## Layout (top to bottom)

1. **Editorial header** (see `components/editorial-header.md`)
   - Meta: `MESO 07` / `FORGE LOG`
   - Title: `STRIKE / WHILE / HOT.` — three lines, middle word in phase color
   - Status: `PPLPP / WK 04 OF 07 / ● INTENSIFICATION`

2. **Heat curve** — visual of all weeks as hammer-strike bars
   - Container: `flex items-end justify-between gap-1 h-40`
   - Each week: bar column with height proportional to `volume × intensity / maxHeat`
   - **Completed weeks:** `linear-gradient(180deg, {phase}dd, {phase}66)` — gradient from phase color full opacity fading down
   - **Current week:** solid phase color gradient + `border-top: 2px solid {phase}` + `box-shadow: 0 0 20px {phase}88` + ember glow pulsing below (`blur-md` absolute element)
   - **Upcoming weeks:** `repeating-linear-gradient(45deg, {phase}33 0 2px, transparent 2px 6px)` — diagonal hatch pattern, like unforged metal
   - Staggered fade-in on mount (80ms between bars)
   - Below bars: week labels `W01`…`W07` with current week in `--text-hi`, others in `--text-5`
   - Below labels: 2px "anvil baseline" — `linear-gradient(90deg, #27272a, #525252, #27272a)`

3. **Now Forging callout** — current week detail
   - Container: `border-l-2` in phase color, padding 20px, background `linear-gradient(90deg, {phase}15 0%, transparent)`
   - Label: `NOW FORGING` in `--size-label`, `--text-4`
   - Two-column header:
     - Big number (current week, e.g. `04`) in `--size-big-num` (64px) phase color
     - Right side: phase name (`INTENSIFICATION`) in `--size-item-name` + short description in `--size-small` `--text-4`
   - Stats grid (3 cols): `VOL / INT / RPE` with `--size-stat` values, unit labels below

4. **Remaining Strikes ledger** — upcoming weeks
   - Header: `REMAINING STRIKES` label + count (e.g. `03`)
   - Each row uses the ledger row pattern (`components/ledger-row.md`)
   - Columns: week number (`W05`) / phase indicator (inline variant) / phase name / stats dot-separated (`16·82·9`)
   - No action column — these rows are display-only

5. **Footer mark** — optional, small
   - `THE FOUNDRY — 04/07 — TCC` as a micro-label row with space-between

## Interactions

- **Tap a completed or upcoming week bar on heat curve:** opens that week's detail (future — stub for now)
- **Tap Now Forging callout:** scrolls to today's workout (future — for now, link to Focus Mode)
- **Tap Remaining Strikes row:** opens that week's preview (future — stub)

No reordering on this screen.

## Data required

```ts
type WeekData = {
  week: number;           // 1..N
  phase: 'Accumulation' | 'Intensification' | 'Peak' | 'Deload';
  volume: number;         // total sets planned
  intensity: number;      // % 1RM average
  rpe: number;            // target RPE
  status: 'complete' | 'current' | 'upcoming';
};

type MesoData = {
  number: number;         // mesocycle number (e.g. 7)
  name: string;           // 'PPLPP'
  weeks: WeekData[];
  currentPhase: Phase;
};
```

Loading state: skeleton shows editorial header structure + placeholder bars in `--border-dim`.

## Empty state

If no active mesocycle, replace heat curve and ledger with a single centered block:
- Headline: `NO FORGE ACTIVE`
- Subtext: `Start a mesocycle from Explore`
- CTA: Link to Explore tab in phase-color button

## Acceptance criteria

- [ ] Editorial header matches spec exactly (typography, spacing, colors)
- [ ] Heat curve bars animate in with 80ms stagger on mount
- [ ] Current week bar has ember glow and elevated border
- [ ] Upcoming weeks use diagonal hatch fill, not solid
- [ ] Phase colors pulled from `PHASE_COLORS` registry, not hardcoded per-component
- [ ] Now Forging callout has phase-color left border and gradient background
- [ ] Ledger rows use the shared `<LedgerRow>` component (no duplicated grid)
- [ ] Noise overlay and heat haze are present (from app root, not per-screen)
- [ ] All text uses `--font-display` or `--font-ui` — no Inter, no system font
- [ ] Screen responds to phase change: heat haze and accent adjust when user progresses weeks
