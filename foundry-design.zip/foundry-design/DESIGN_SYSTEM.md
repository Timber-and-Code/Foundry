# Foundry Design System

Tokens and patterns that make the app feel like Foundry on every screen. This is the source of truth — if a value here conflicts with a screen spec, this wins.

---

## Color

### Foundation

```
--bg-deep:      #0a0907   /* app background base */
--bg-warm:      #13100e   /* mid-layer warm black */
--bg-ember:     #1f1815   /* top-layer, picked up by heat haze */

--surface-1:    rgba(20, 16, 14, 0.5)    /* reference blocks, subtle fills */
--surface-2:    rgba(15, 12, 11, 0.6)    /* up-next card, sheet backgrounds */

--border-dim:   #1a1614   /* horizontal rules between rows */
--border-1:     #1f1c1a   /* card borders, ref blocks */
--border-2:     #262626   /* input underlines, nav buttons */
--border-3:     #404040   /* hover states, dashed placeholders */
```

### Text

```
--text-hi:      #f5f5f5   /* headlines, active numbers */
--text-1:       #e5e5e5   /* body default */
--text-2:       #d4d4d4   /* secondary values */
--text-3:       #a3a3a3   /* tertiary, session meta */
--text-4:       #737373   /* labels, prev-week data */
--text-5:       #525252   /* placeholders, column headers */
--text-6:       #404040   /* disabled, counts */
```

### Phase palette

These colors are tied to mesocycle phases. Use them for the phase indicator on the current item, never as decoration.

```
--phase-accum:     #E8E4DC   /* Accumulation  — bone / unworked steel */
--phase-intens:    #E8651A   /* Intensification — forge orange */
--phase-peak:      #D4983C   /* Peak — gold, tempered */
--phase-deload:    #5B8FA8   /* Deload — cool blue, quenched */
```

`--phase-intens` doubles as the app's primary accent `--accent`. When the user is in an Intensification block, the app feels orange-hot. In Deload, the app shifts cool. This is intentional — phase color is global atmosphere, not just a badge.

### Accent usage rules

- Primary CTA background
- Current state (active exercise, active set, current week)
- Progress fill on a bar that represents completion
- Phase indicator for the current phase

**Never** use `--accent` for:
- Body text
- Borders on non-interactive elements
- Decorative lines or dividers
- Hover states on secondary elements

---

## Typography

### Families

```
--font-display: 'Bebas Neue', sans-serif        /* all headlines, large numbers */
--font-ui:      'JetBrains Mono', monospace     /* everything else: labels, body, inputs, nav */
```

No Inter. No system UI font. The mono UI type is non-negotiable — it's the single biggest identity move in the system.

### Scale

Display (Bebas Neue):
```
--size-hero:       56px / line 0.88   /* top of a primary screen */
--size-screen:     48px / line 0.90   /* screen title */
--size-section:    44px / line 0.92   /* focused exercise name */
--size-big-num:    64px / line 1.00   /* stat emphasis */
--size-stat:       30px / line 1.00   /* stat values in grids */
--size-item-name:  22px / line 1.00   /* list item names */
--size-card-title: 20px / line 1.00   /* up-next, callout titles */
--size-set-num:    20px / line 1.00   /* set row numbers */
```

UI (JetBrains Mono, typically uppercase with tracking):
```
--size-body:       13px
--size-input:      15px
--size-meta:       12px
--size-small:      11px
--size-label:      10px   /* uppercase, letter-spacing 0.25em–0.30em */
--size-micro:      9px    /* column headers, tags, footer marks */
```

### Letter-spacing

All-caps mono UI text gets tracking. This makes labels feel deliberate:

```
--track-label:    0.25em   /* default for labels like "TARGET", "LAST WEEK" */
--track-wide:     0.30em   /* micro labels, column headers */
--track-brand:    0.20em   /* brand/session titles */
```

---

## Spacing

```
--sp-0.5:  2px
--sp-1:    4px
--sp-2:    8px
--sp-3:    12px
--sp-4:    16px
--sp-5:    20px
--sp-6:    24px
--sp-8:    32px
--sp-10:   40px
--sp-12:   48px
```

Default container gutter: `--sp-5` (20px). Bottom safe area for the fixed nav bar: `--sp-32` (120–140px) when a nav bar is present.

---

## Radius

Corners are minimal or absent. This is an industrial aesthetic; rounded cards fight it.

```
--radius-none:    0
--radius-hairline: 2px  /* maximum for any UI element */
```

Buttons, inputs, sheets, cards — all `--radius-none`. The only exception is the session progress dot indicator and similar circular elements (which are full circles, not rounded rectangles).

---

## Signature patterns

These are the pieces that make every screen feel like Foundry. Apply to every route.

### 1. Noise overlay

Fixed to the viewport, sits above the background and below all content. SVG turbulence filter at 8% opacity with `mix-blend-mode: overlay`. See `components/noise-overlay.md`.

### 2. Heat haze

A radial orange gradient, 320–384px tall, anchored to the top of the scroll container. Color matches the current phase. See `components/heat-haze.md`.

### 3. Editorial header

Every primary screen opens with a meta row → divider → oversized Bebas headline → status line. Asymmetric, confident, leans on type hierarchy. See `components/editorial-header.md`.

### 4. Ledger row

Rows instead of cards. Thin border-bottom (`--border-dim`), dense horizontal rhythm, phase-color accent bar on the left when active. See `components/ledger-row.md`.

### 5. Phase indicator

A 2–4px vertical bar in the phase color, positioned on the left edge of the active container. When it's the current state, it glows (`box-shadow: 0 0 12px <phase-color>`). See `components/phase-indicator.md`.

---

## Motion

Three allowed animations. Everything else is instant.

### Current-state pulse

Small ember dot or indicator that pulses on the currently-active element (session timer, active phase marker).

```
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50%      { opacity: 0.4; }
}
/* 1.5s ease-in-out infinite */
```

### Ring burst (on state-change confirmation)

When a set is logged, the complete button emits a single ring that scales outward and fades.

```
@keyframes ring {
  0%   { transform: scale(1);   opacity: 1; }
  100% { transform: scale(1.8); opacity: 0; }
}
/* 0.6s ease-out, single iteration */
```

### Staggered reveal (on screen mount)

Lists and chart-like elements fade up with an 80ms stagger between items. 600ms per item, ease-out.

```
opacity: 0 → 1
transform: translateY(12px) → 0
```

### Forbidden

No bouncy springs. No hover lift on cards. No transitions on color changes for text. No bounce/overshoot. No skeleton shimmer. If an interaction needs to feel responsive, solve it with opacity + transform, not with decorative easing.

---

## Haptics

When running inside Capacitor (the production packaged app):

- Light haptic on set logged (`Haptics.impact({ style: ImpactStyle.Light })`)
- Medium haptic on long-press activated for drag (`Haptics.impact({ style: ImpactStyle.Medium })`)
- Light haptic on drag drop

Inside the web PWA, call `navigator.vibrate(15)` as a fallback where supported.

---

## Language

Foundry has a forge metaphor in its *visuals and branding*. The *UI copy stays functional*. Distinct aesthetic, boring language — that's the formula.

Use:
- "Rest" (not "Cooling")
- "Complete set" / "Log set" (not "Strike")
- "Add set" (not "Add strike")
- "Finish workout" (not "Quench")
- "Last week" (not "Previous forging")
- "Current" (not "Now forging")

Reserve forge language for:
- Marketing copy / landing page
- Empty states and loading screens (one-shot moments where personality adds charm)
- Achievement / milestone copy ("Forged" as a past-tense completion state is fine)
