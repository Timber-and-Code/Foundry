# Foundry Design Docs

Visual and interaction specs for The Foundry. Source of truth for UI/UX decisions, referenced by Claude Code during implementation sessions.

## Structure

- `DESIGN_SYSTEM.md` — tokens (colors, type, spacing), signature patterns, motion conventions. Read first.
- `screens/` — one file per screen. Each references `DESIGN_SYSTEM.md` for tokens rather than repeating them.
- `components/` — reusable pattern specs (phase indicator, heat haze, ledger row, etc.).
- `mockups/` — static HTML reference files. Open in a browser to see the target. Not source; do not parse or copy DOM from these into React.

## How to use with Claude Code

Start each session by opening the relevant files in VS Code:

```
DESIGN_SYSTEM.md
screens/03-focus-mode.md   (or whatever you're working on)
```

Then prompt Claude Code:

> Read DESIGN_SYSTEM.md and screens/03-focus-mode.md. Implement the Focus Mode screen per the spec using existing Foundry components where they fit and creating new ones where noted. Use dnd-kit for the reorder sheet. Stop after the screen renders and we'll review before wiring logic.

The forge aesthetic is consistent across all screens — if you're building a new screen and it's not covered in `screens/`, reference `DESIGN_SYSTEM.md` alone and make choices consistent with the existing screen specs.

## Design principles (short version)

1. **One accent color working hard.** `#E8651A` only where it means something (current state, primary action, phase indicator). Everything else is greyscale on warm dark.
2. **Typography carries identity.** Bebas Neue for display/numbers, JetBrains Mono for UI text, no Inter.
3. **Texture, not decoration.** Noise overlay + heat haze gradient on every screen. Skip cards, shadows, rounded corners.
4. **Boring functional language, distinctive visual language.** No "quench" or "strike" copy in UI. Say "Rest," "Complete," "Finish." Let the visuals do the personality.
5. **Motion is rare and meaningful.** Current-state pulse, ring burst on set logged, staggered reveal on load. That's it — no bouncy springs elsewhere.
