/**
 * The Foundry — AI Program Builder Proxy
 * Cloudflare Worker that holds the Anthropic API key server-side
 * and forwards requests from the app to the Anthropic API.
 *
 * Deploy with: wrangler deploy
 * Set secret:  wrangler secret put ANTHROPIC_API_KEY
 */

const ALLOWED_ORIGINS = [
  "https://timber-and-code.github.io",
  "http://localhost",
  "http://127.0.0.1",
];

function corsHeaders(origin) {
  const allowed = ALLOWED_ORIGINS.some(o => origin?.startsWith(o))
    ? origin
    : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowed,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400",
  };
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";

    // Handle CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders(origin),
      });
    }

    // Only accept POST
    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), {
        status: 405,
        headers: { ...corsHeaders(origin), "Content-Type": "application/json" },
      });
    }

    // Parse the incoming body — expects the same shape as Anthropic /v1/messages
    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
        status: 400,
        headers: { ...corsHeaders(origin), "Content-Type": "application/json" },
      });
    }

    // Enforce safety limits — cap tokens to prevent runaway costs
    const safeBody = {
      ...body,
      model: body.model || "claude-haiku-4-5-20251001",
      max_tokens: Math.min(body.max_tokens || 1024, 2048),
    };

    // Forward to Anthropic
    let anthropicResponse;
    try {
      anthropicResponse = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify(safeBody),
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: "Failed to reach Anthropic API", detail: err.message }), {
        status: 502,
        headers: { ...corsHeaders(origin), "Content-Type": "application/json" },
      });
    }

    // Stream or buffer the response back
    const responseBody = await anthropicResponse.text();

    return new Response(responseBody, {
      status: anthropicResponse.status,
      headers: {
        ...corsHeaders(origin),
        "Content-Type": "application/json",
      },
    });
  },
};
