# THE FOUNDRY — Project Synopsis
**Fitness PWA · v1.15.0 · March 2026**

> Single-file React PWA. No bundler. All state in localStorage. Built session by session.

---

## 1 · Mission & Revenue Objective

The Foundry is a periodized strength training PWA built for serious athletes and committed beginners. It generates personalized mesocycles, auto-progresses weights, tracks volume landmarks, and delivers what a $200/month personal trainer would give you — for the price of a streaming subscription.

**PRIMARY OBJECTIVE: $100,000 in revenue within 12 months of launch.**

Every feature decision, pricing tier, and growth initiative must be evaluated against this target. A beautiful app that doesn't convert is a hobby. We are building a business.

---

## 2 · Pricing Model & Path to $100K

| Tier | Price | Includes |
|------|-------|----------|
| **Free** | $0 — always free for: Under 18 · Adults 62+ | Manual program builder, full tracking, exercise library, warmup guides |
| **Pro** | $12/mo · $99/yr (save 2 months) | AI program builder, full history, sparklines, e1RM, all advanced features |
| **Trainer / Coach** | $29/mo · $249/yr — post-Capacitor | Client management, shared programs, coach dashboard |

### The Math to $100K
- 700 active Pro subscribers at $12/mo = $100,800 ARR
- Or: 850 annual at $99 + ~200 monthly = $102,550
- Tyler's business banking network is the primary warm acquisition channel
- Every trainer using the app is a distribution node — 10 trainers × 20 clients = 200 users from 10 conversations
- James's niece Sydney (works at a gym) = target for trainer tier pilot + real-user feedback

---

## 3 · Architecture

| Item | Detail |
|------|--------|
| Format | Single HTML file (~13,377 lines) |
| Framework | React 18 (CDN), no bundler, no build step |
| State | localStorage under `ppl:` namespace |
| AI Backend | Cloudflare Worker → `https://foundry-ai.timberandcode3.workers.dev` |
| AI Key | Stored as Cloudflare Worker secret `ANTHROPIC_API_KEY` — never in source |
| Hosting | GitHub Pages — `https://timber-and-code.github.io/Foundry` |
| Versioning | Semantic: Major = architecture rebuild, Minor = new features, Patch = fixes/polish |
| Worker Files | `~/foundry-worker/worker.js` + `wrangler.toml` on James's WSL2 machine |

**Vite/Capacitor migration:** Deferred until App Store push (v2.0 sprint). No current bottleneck.

---

## 4 · Current Version — v1.15.0

### What's New in v1.15.0

**AI Worker — Live**
- Cloudflare Worker deployed at `https://foundry-ai.timberandcode3.workers.dev`
- ANTHROPIC_API_KEY stored as encrypted Cloudflare secret
- CORS locked to `timber-and-code.github.io` and localhost only
- Max tokens capped at 2048 to prevent cost runaway
- App no longer falls back on every setup — AI is live

**UI/UX Overhaul — Phase 1**
- Home tab is now the default landing for all users (removed "explore first" for new users)
- Card title sizes unified across Home / Progress / Schedule tabs (`fontSize:15, fontWeight:700, primary`)
- Phase colors updated to Option 1 palette: ACC `#2dd4a8` · INT `#5ba8ff` · PEA `#f5a623` · DEL `#c084fc`
- Phase colors synced between CSS variables AND `PHASE_COLOR` JS constant (was split causing calendar mismatch)
- Light mode card backgrounds darkened for better contrast
- Minimized rest timer uses `--timer-mini-bg` (`#3a3f44` dark / inset light) — no longer blends with exercise card

**Schedule Tab**
- Calendar cells colored by meso phase (not hardcoded teal/blue)
- Month navigation with ‹ › buttons and TODAY pill
- 3-letter DOW headers (Sun Mon Tue...) at 11px
- Clicking a day navigates to that workout; add-workout only offered for today/future
- Phase color legend in calendar footer (ACC / INT / PEA / DEL)

**Progress Tab**
- "Progress" header bumped to 17px bold
- Volume Trend chart now collapsible — tap to expand, includes plain-English explainer
- Sparkline W-labels use `text-muted` (visible in dark mode)
- PR Tracker embedded label matches card title style

**Quote Library — 233 quotes**
- Added Kobe Bryant (10), Marcus Aurelius (10), Serena Williams (7), Simone Biles (5), Epictetus (8), Nietzsche (8), Nick Saban (7), Cristiano Ronaldo (6), Ronnie Coleman (7), Mark Divine (6)
- Added Jocko Willink (11), David Goggins (12), Tony Robbins (12), Jay Shetty (12)
- Leave-workout prompt now draws from full 233-quote library via `randomQuote()` — not hardcoded 6-quote array

**Bug Fixes**
- Day locking removed — users can log any day in any order regardless of prior completions
- `selectedExtraDate` / `setView("extra")` crash in HomeView fixed — now uses `onOpenExtra()` prop
- `+3 more exercises` leftover removed from Next Session card — all exercises shown
- `PHASE_COLOR` JS constant synced to new palette (was causing calendar to show wrong colors)
- Rest timer now fires on ALL sets including the last — last set uses next exercise's rest period (or 90s if final exercise)
- Meso History header updated to match Progress/Schedule style (`17px bold primary`)

**Week Cards — Phase Color Borders**
- Every week card on Schedule tab outlined in its phase color (not just current week)
- Day rows get 3px left accent bar in phase color
- Home tab current week card border uses phase color

---

## 5 · Storage Key Reference

| Key Pattern | Purpose |
|-------------|---------|
| `ppl:profile` | User profile JSON |
| `ppl:done:d{d}:w{w}` | Meso session completion flag |
| `ppl:day{d}:week{w}` | Set/rep data for meso session |
| `ppl:sess:lift:d{d}:w{w}` | Session duration (minutes) |
| `ppl:sessionStart:d{d}:w{w}` | Session start timestamp (ms) |
| `ppl:strengthEnd:d{d}:w{w}` | Strength phase end timestamp (ms) |
| `ppl:extra:YYYY-MM-DD` | Extra session day object JSON |
| `ppl:extra:done:YYYY-MM-DD` | Extra session completion flag |
| `ppl:extra:start:YYYY-MM-DD` | Extra session start timestamp |
| `ppl:extra:end:YYYY-MM-DD` | Extra session strength end timestamp |
| `ppl:extra:data:YYYY-MM-DD` | Extra session set/rep data |
| `ppl:bwlog` | Bodyweight log array JSON |
| `ppl:currentWeek` | Current meso week index |
| `ppl:theme` | Dark/light theme preference |
| `ppl:archive` | Completed meso archive array (max 10) |
| `ppl:exov:d{d}:ex{i}` | Exercise override (swap) for slot |
| `ppl:notes:d{d}:w{w}` | Session notes text |
| `ppl:cardio:d{d}:w{w}` | Cardio log for session |

---

## 6 · Key Code Locations (v1.15.0)

| Item | Location |
|------|---------|
| `FOUNDRY_AI_WORKER_URL` | ~line 4349 |
| `PHASE_COLOR` JS constant | ~line 3029 |
| `QUOTES` array (233 quotes) | ~line 3416 |
| `randomQuote()` | ~line 3721 |
| `generateExtraWorkout()` | ~line 4193 |
| `ExtraDayView` | ~line 7313 |
| `DayView` | ~line 7730 |
| `beginWorkout()` | Inside DayView ~line 7800 |
| `handleSetLogged()` | Inside DayView ~line 7883 |
| `handleSetCheckmark()` | Inside ExerciseCard ~line 6655 |
| `doComplete()` | Inside DayView ~line 8015 |
| Rest timer render (minimizable) | ~line 8117 |
| Leave prompt (uses randomQuote) | ~line 8340 |
| `WeekSection` (phase color borders) | ~line 9353 |
| `ProgressPage` | ~line 9835 |
| `PRTracker` | ~line 12494 |
| `MesoHistory` | ~line 12186 |
| `HomeView` | ~line 10733 |
| Calendar grid + phase colors | ~line 11490 |
| Calendar month nav (‹ ›) | ~line 11448 |
| `App` view routing | ~line 13183 |

---

## 7 · QA Tracker

### ✅ Resolved
| # | Issue |
|---|-------|
| 1 | AI Worker URL was placeholder — now live at `foundry-ai.timberandcode3.workers.dev` |
| 2 | Day locking blocked out-of-order logging — removed entirely |
| 3 | Leave prompt used 6-quote hardcoded array — now uses full 233-quote library |
| 4 | Rest timer skipped last set — now fires on all sets, uses next exercise's rest |
| 5 | Meso History header small/dimmed — updated to match Progress/Schedule |

### 🟡 UX Issues (next up)
| # | Issue |
|---|-------|
| 7 | No indicator on Home/Progress/Schedule that a workout is in progress |
| 8 | BW check-in fires on exercise expand, not session start |
| 9 | Edit Workout button disappears on completed days once next day is unlocked |
| 10 | Session notes buried below all exercises |
| 11 | Week Complete modal "View Week Summary" underutilized |
| 12 | Schedule calendar navigates infinitely into the past |
| 13 | Exercise swap UI doesn't confirm which week it applies to |

### 🟢 Feature Gaps (after UX)
| # | Issue |
|---|-------|
| 15 | No PR callout in workout complete modal |
| 16 | Body weight trend — data collected but never visualized |
| 17 | No read-only preview of future sessions from calendar |
| 18 | Exercise history week numbers don't map to current meso context |
| 19 | No haptic feedback on key moments |
| 20 | Explore sample programs have no "Start this program" button |
| 21 | Onboarding doesn't show what users see when they first land |
| 22 | No way to update workout days mid-meso without full reset |
| 23 | No rest day content |
| 24 | font-weight 900 used but not loaded in Google Fonts subset |

---

## 8 · Product Roadmap (Priority Order)

1. **Paywall on AI builder** — Free tier gets static generator, Pro gets AI. Clearest monetization lever.
2. **Onboarding share prompt** — Post-program-generation nudge. Low effort, word-of-mouth capture.
3. **Progress photos** — Camera upload pinned to date. Retention driver and differentiator.
4. **Trainer tier** — Trainer creates "team," pushes programs to clients. Sydney's gym = pilot.
5. **Recovery & Readiness section** — Sleep, stress, HRV. Bridge to "Foundry Whole Health" long-term vision.
6. **Rest day content** — Mobility/recovery on off days. Keeps DAU up.
7. **Body weight benchmarks** — Entry point for users who don't know working weights.
8. **Push notifications** — Requires Capacitor native wrap first.
9. **In-app referral code** — "Give friend 30 days free, get 30 days free."

**Vite + Capacitor = v2.0 sprint.** Trigger: when starting App Store push.

---

## 9 · Standing Instructions

- Ask before making changes not explicitly requested
- Deliver updated SYNOPSIS.md at end of every build session
- Proactively surface $100K revenue ideas each session
- `index.html` on GitHub = live app. User uploads manually
- GitHub upload page: `https://github.com/Timber-and-Code/Foundry/upload/main`
- Working file lives at `/home/claude/Foundry_1_15_0.html` in each session
- Outputs always copied to `/mnt/user-data/outputs/`
