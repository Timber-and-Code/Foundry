# THE FOUNDRY — Project Synopsis
**Fitness PWA · v1.14.0 · March 2026**

> Single-file React PWA. No bundler. All state in localStorage. Built session by session.

---

## 1 · Mission & Revenue Objective

The Foundry is a periodized strength training PWA built for serious athletes and committed beginners. It generates personalized mesocycles, auto-progresses weights, tracks volume landmarks, and delivers what a $200/month personal trainer would give you — for the price of a streaming subscription.

**PRIMARY OBJECTIVE: $100,000 in revenue within 12 months of launch.**

Every feature decision, pricing tier, and growth initiative must be evaluated against this target. A beautiful app that doesn't convert is a hobby. We are building a business.

---

## 2 · Pricing Model & Path to $100K

| Tier | Price | Includes |
|------|-------|----------|
| **Free** | $0 — always free for: Under 18 · Adults 62+ | Manual program builder, full tracking, exercise library, warmup guides |
| **Pro** | $12/mo · $99/yr (save 2 months) | AI program builder, full history, sparklines, e1RM, all advanced features |
| **Trainer / Coach** | $29/mo · $249/yr — post-Capacitor | Client management, shared programs, coach dashboard |

### The Math to $100K
- 700 active Pro subscribers at $12/mo = $100,800 ARR
- Or: 850 annual at $99 + ~200 monthly = $102,550
- Tyler's business banking network is the primary warm acquisition channel
- Every trainer using the app is a distribution node — 10 trainers × 20 clients = 200 users from 10 conversations
- James's niece Sydney (works at a gym) = target for trainer tier pilot + real-user feedback

---

## 3 · Architecture

| Item | Detail |
|------|--------|
| Format | Single HTML file (~13,000+ lines) |
| Framework | React 18 (CDN), no bundler, no build step |
| State | localStorage under `ppl:` namespace |
| AI Backend | Cloudflare Worker proxy → Anthropic API (`foundry-ai-proxy.timberandcode3.workers.dev`) |
| Hosting | GitHub Pages — `https://timber-and-code.github.io/Foundry` |
| Versioning | Semantic: Major = architecture rebuild, Minor = new features, Patch = fixes/polish |

**Vite/Capacitor migration:** Deferred until App Store push (v2.0 sprint). No current bottleneck.

---

## 4 · Current Version — v1.14.0

### v1.14.0 Feature Set (current build)

**Session Timer — Explicit Begin/End**
- Timer starts on "Begin Workout" click, not on page mount — session duration is now accurate
- Start timestamp persisted to `ppl:sessionStart:d{d}:w{w}` — survives navigation away and back
- Live elapsed timer (⏱ M:SS) displayed in workout header while active
- Leave guard: back button during active session shows motivational quote prompt, session stays live
- Timer stops and clears on doComplete()

**Minimizable Rest Timer**
- Full-screen rest modal now has a MINIMIZE ↓ button
- Minimized state: slim bar pinned above nav bar with live countdown, color-coded progress fill, exercise name
- Tap bar to expand back to full modal
- Color shifts: blue → amber → red as rest winds down; goes green "GO!" when done

**Edit Mode for Completed Workouts**
- ✎ Edit Workout button appears in header after session is marked complete
- Unlocks all exercise inputs, swap buttons, and Add Exercise
- Weight changes recalculate e1RM via existing data flow
- Timer never restarts on edit

**Calendar — Add Workout from Any Date**
- Every calendar date is tappable
- Tap a date → Add Workout modal: ⚡ Foundry Build or ✏️ Manual
- Foundry Build: prompts day type options based on current split (PPL → Push/Pull/Legs/Full; Upper/Lower → Upper/Lower/Full; Full Body → Full/Push/Pull/Legs)
- generateExtraWorkout() uses same pool/builder logic as main program generator
- Manual: creates blank session marker
- Extra sessions saved to `ppl:extra:YYYY-MM-DD`
- Blue dot on calendar cells that have an extra session

**Extra Session Flow (ExtraDayView)**
- Creating a session navigates directly into ExtraDayView
- Tapping an existing extra dot on calendar reopens that session
- Begin Workout overlay shows exercise preview (up to 4 exercises listed)
- Weight carryover: looks up last logged weight for each exercise by ID across all meso data
- Full exercise card functionality: expand/collapse, set logging, swap, add exercise
- Post-strength prompt when all sets complete
- doComplete() saves to `ppl:extra:done:YYYY-MM-DD`, fires WorkoutCompleteModal with full stats
- Edit mode for completed extra sessions
- Leave prompt with session resume on return

---

## 5 · Storage Key Reference

| Key Pattern | Purpose |
|-------------|---------|
| `ppl:profile` | User profile JSON |
| `ppl:done:d{d}:w{w}` | Meso session completion flag |
| `ppl:day{d}:week{w}` | Set/rep data for meso session |
| `ppl:sess:lift:d{d}:w{w}` | Session duration (minutes) |
| `ppl:sessionStart:d{d}:w{w}` | Session start timestamp (ms) |
| `ppl:strengthEnd:d{d}:w{w}` | Strength phase end timestamp (ms) |
| `ppl:extra:YYYY-MM-DD` | Extra session day object JSON |
| `ppl:extra:done:YYYY-MM-DD` | Extra session completion flag |
| `ppl:extra:start:YYYY-MM-DD` | Extra session start timestamp |
| `ppl:extra:end:YYYY-MM-DD` | Extra session strength end timestamp |
| `ppl:extra:data:YYYY-MM-DD` | Extra session set/rep data |
| `ppl:bwlog` | Bodyweight log array JSON |
| `ppl:currentWeek` | Current meso week index |

---

## 6 · Key Code Locations (v1.14.0)

| Item | Location |
|------|---------|
| `generateExtraWorkout()` | ~line 4100 |
| `ExtraDayView` | ~line 7171 |
| `DayView` | ~line 7424 |
| `beginWorkout()` | Inside DayView ~line 7460 |
| `formatElapsed()` | Inside DayView ~line 7448 |
| `doComplete()` | Inside DayView ~line 7825 |
| Rest timer render (minimizable) | ~line 7635 |
| Add Workout Modal | ~line 10565 |
| Calendar date click handler | ~line 11175 |
| `App` view routing | ~line 13140 |
| `FOUNDRY_AI_WORKER_URL` | ~line 4140 |

---

## 7 · Product Roadmap (Priority Order)

1. **Paywall on AI builder** — Free tier gets static generator, Pro gets AI. Clearest monetization lever.
2. **Onboarding share prompt** — Post-program-generation nudge. Low effort, word-of-mouth capture.
3. **Progress photos** — Camera upload pinned to date. Retention driver and differentiator.
4. **Trainer tier** — Trainer creates "team," pushes programs to clients. Sydney's gym = pilot.
5. **Recovery & Readiness section** — Sleep, stress, HRV. Bridge to "Foundry Whole Health" long-term vision without building a separate product.
6. **Rest day content** — Mobility/recovery on off days. Keeps DAU up.
7. **Body weight benchmarks** — Entry point for users who don't know working weights.
8. **Push notifications** — Requires Capacitor native wrap first.
9. **In-app referral code** — "Give friend 30 days free, get 30 days free."

**Vite + Capacitor = v2.0 sprint.** Trigger: when starting App Store push.

---

## 8 · Standing Instructions

- Ask before making changes not explicitly requested
- Deliver updated SYNOPSIS.md at end of every build session
- Proactively surface $100K revenue ideas each session
- `index.html` on GitHub = live app. User uploads manually
- GitHub upload page: `https://github.com/Timber-and-Code/Foundry/upload/main`
